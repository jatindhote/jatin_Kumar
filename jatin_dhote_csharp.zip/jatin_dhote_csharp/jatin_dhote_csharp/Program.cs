﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jatin_dhote_csharp
{

    class Employee
    {
        public string Emp_Name { get; set; }
            
        public int Emp_Age { get; set; }

        public string Emp_Address { get; set; }

        public string Emp_Email { get; set; }


        static void Main(string[] args)
        {
            Employee emp1 = new Employee();
            while (true)
            {
                Console.WriteLine("Press 1 to Create value");
                Console.WriteLine("Press 2 to Update value");
                Console.WriteLine("Press 3 to Read value");
                Console.WriteLine("Press 4 to Delete value;");


                int process = Convert.ToInt32(Console.ReadLine());

                switch (process)
                {
                    case 1:
                        Console.WriteLine("Please Enter the Emp_Name !");
                        string Emp_Name = Console.ReadLine();

                        Console.WriteLine("Please Enter the Emp_Age !");
                        int Emp_Age = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("Please Enter the Emp_Address !");
                        string Emp_Address = Console.ReadLine();

                        Console.WriteLine("Please Enter the Emp_Email !");
                        string Emp_Email = Console.ReadLine();

                        emp1.Emp_Name = Emp_Name;
                        emp1.Emp_Age = Emp_Age;
                        emp1.Emp_Address = Emp_Address;
                        emp1.Emp_Email = Emp_Email;

                        Console.WriteLine("Process Done, Data is saved");
                        break;

                    case 2:
                        Console.WriteLine("Current name =" + emp1.Emp_Name + " " + "Please Enter the Updated Name !");
                        string Emp_Nameu = Console.ReadLine();

                        Console.WriteLine("Current age =" + emp1.Emp_Age + " " + "Please Enter the Updated Age !");
                        int Emp_Ageu = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("Current address =" + emp1.Emp_Address + " " + "Please Enter the Updated Address !");
                        string Emp_Addressu = Console.ReadLine();

                        Console.WriteLine("Current Email =" + emp1.Emp_Email + " " + "Please Enter the email !");
                        string Emp_Emailu = Console.ReadLine();

                        emp1.Emp_Name = Emp_Nameu;
                        emp1.Emp_Age = Emp_Ageu;
                        emp1.Emp_Address = Emp_Addressu;
                        emp1.Emp_Email = Emp_Emailu;
                        Console.WriteLine("Process Done, Data is Updated Successfully");

                        break;

                    case 3:
                        Console.WriteLine("Current name =" + emp1.Emp_Name);
                        Console.WriteLine("Current age =" + emp1.Emp_Age);
                        Console.WriteLine("Current address =" + emp1.Emp_Address);
                        Console.WriteLine("Current email =" + emp1.Emp_Email);
                        break;

                    case 4:
                        emp1.Emp_Name = null;
                        emp1.Emp_Age = 0;
                        emp1.Emp_Address = null;
                        emp1.Emp_Email = null;
                        Console.WriteLine("Process Done, Data is Deleted Successfully");

                        break;
                    default:
                        Console.WriteLine("Choose the Correct Option");
                        break;
                }
            Console.ReadLine();
            }
        }
    }
}
